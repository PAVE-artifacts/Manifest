#import pa_decoder

#import data_to_list 
import auto_pa_decoder_verifier

#pa_hint = pa_decoder.pa_hint_lifter('test_function.pvs')

pa_verifer = auto_pa_decoder_verifier.verifier('target.txt')
     
#pa_names = pa_hint.print_pvs_2_list_nline()

#pa_rewrite = pa_hint.pa_rewrite()

pa_verify = pa_verifer.verify_all()