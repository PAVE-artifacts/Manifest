import sys
import json
import re
import collections
import os

#pvs_file = sys.argv[1]
#stats_file = sys.argv[2]
#search_block_num_per_func = sys.argv[3]
#search_inst_num_per_func  = sys.argv[4]


class pa_hint_lifter:
    """ radare's disassembler does not support pac inst 
        radare produces hint inplace of the pac inst
        this class has methods to fix pvs files with 
        a special decoder.  
    """
    def __init__ (self, pvs_file):
        """ takes pvs file with hints"""
        self.pvs_file = pvs_file
        
    def pvs_2_list(self):
        with open(self.pvs_file, 'r') as datafile:
            Listdata = [line.split('=') for line in datafile.readlines()]
        return Listdata
        
    def extract_pvs_bin(self):
        pvs_as_list = self.pvs_2_list()
        pvs_bin_vec = [ line[2].split()[3][2:] 
                         for line in pvs_as_list 
                         if len(line) > 2 ]
        return pvs_bin_vec
      
    def extract_names_list(self):
        """ returns a list of the instructions in each pvs bb file
        """
        pvs_as_list = self.pvs_2_list()
        inst_names = [ line[0].split()[0] 
                 for line in pvs_as_list
                 if len(line) > 2]
        longest_string = max(inst_names, key=len)
        max_ident = len(longest_string)
        l = len(inst_names)
        return [max_ident ,l]
     
    def print_pvs_2_list_nline(self):
        with open(self.pvs_file, 'r') as datafile:
            Listdata = [line.split() for line in datafile.readlines()]
        return Listdata    
    
    def pa_decode(self, bv):
        """ Special decoder based on ASL 
            arg: acts on extracted bv bin from pvs file
        """
        pattern_pacia = re.compile("1101010100000011001000[10]100[10]11111")
        pattern_autia = re.compile("1101010100000011001000[10]110[10]11111")
        vb = bv[::-1]
        op2 = bv[5:8]
        CRm = bv[8:12]
        inx = op2+CRm
        x   = inx[::-1]
        if pattern_pacia.fullmatch(vb) != None:            
            if   x == '0011001':
                return 'paciasp'
            elif x == '0001000':
                return 'pacia1716'
            elif x == '0011000':
                return 'paciaz'
            else: 
                #raise NameError('not emplemented')
                return 'not emplemented'
        elif pattern_autia.fullmatch(vb) != None:
            if   x == '0011101':
                return 'autiasp'
            elif x == '0001100':
                return 'autia1716'
            elif x == '0011100':
                return 'autiaz'
            else:
                #raise NameError('not emplemented')
                return 'not emplemented'
        else:
            return bv
         
        
    def create_header(self, func_name):
        header = ("t_"+func_name+"[ ( importing arm_state ) p_pre : s ] : THEORY\n\n"
                  "BEGIN\n\n" "IMPORTING "+func_name+"[ p_pre ]\n\n")
        return header
        
    def create_lemma(self,nu_name):
        if nu_name[0:3] == 'aut':
            soundness_lemma = 'pa_local_soundness: Theorem ('+nu_name+'.autiacond = false) and ('+nu_name+'.post`except = "") => false '
            completeness_lemma = 'pa_local_completeness : Theorem  '+nu_name+'.autiacond and'+nu_name+'.post`except = "error_code" => false'
            return soundness_lemma +"\n\n"+completeness_lemma+"\n\n"
        else:
            return " "
        
    def create_proof(self, func_name, nu_name ,pre_state):
        if nu_name[0:3] == 'aut':
            
            soundness_proof =("%|- pa_local_soundness : PROOF\n"
            "%|- (then (flatten) (expand \"post\") (expand \"AuthIA\") (lift-if -2)\n"
            "%|-  (spread\n"
            "%|-   (claim\n"
            "%|-    \"not AuthIA["+func_name+"[p_pre]."+pre_state+"].sts1`Enable = bv[1](0b0)\")\n"
            "%|-   ((then (hide -1) (assert) (reveal -1) (expand \"r\" -2) (lift-if -2)\n"
            "%|-     (spread (split -2)\n"
            "%|-      ((then (assert) (expand \"autiacond\") (hide 2) (expand \"AuthIA\")\n"
            "%|-        (propax))\n"
            "%|-       (then (flatten -1) (expand \"autiacond\") (expand \"AuthIA\")\n"
            "%|-        (expand \"PAcond\")\n"
            "%|-        (spread (split 2)\n"
            "%|-         ((then (flatten 1) (assert -2))\n"
            "%|-          (then (flatten 1)\n"
            "%|-           (spread (split 2) ((assert -1) (assert -1))))))))))\n"
            "%|-    (then (hide -2) (assert)) (eval-formula 1))))\n"
            "%|- QED\n")
            
            completeness_proof = ( "%|- pa_local_completeness : PROOF\n"
            "%|- (then (skosimp*) (expand \""+nu_name+".autiacond\") (expand \"AuthIA\")\n"
            "%|-  (spread (split)\n"
            "%|-   ((propax)\n"
            "%|-    (then (flatten -1) (expand \""+nu_name+".post\") (expand \"AuthIA\")\n"
            "%|-     (claim\n"
            "%|-      \" not AuthIA["+func_name+"[p_pre]."+pre_state+".post].sts1`Enable = bv[1](0b0)\")\n"
            "%|-     (assert) (expand \"r\" -2) (expand \"PAcond\" -1)\n"
            "%|-     (spread (split)\n"
            "%|-      ((then (flatten -1) (assert)) (then (flatten -1) (assert))))))))\n"
            "%|- QED" )
            return soundness_proof+"\n\n"+ completeness_proof
        else:
            pass  
        
    def create_closer (self, func_name):
        closer = "\n END "+"t_"+func_name
        return closer
            
    def pa_rewrite(self):
        """ writes new valid pvs file with lemmas and build dynamically thier proof scripts.
        """
        pvs_re_rewrite = self.print_pvs_2_list_nline()
        enum_list = list(enumerate(pvs_re_rewrite)) # gives an index to a line
        #print(len(enum_list))
        body_len = self.extract_names_list()
        up_bound = body_len[1]
        func_name = "func_"+enum_list[0][1][0][:-1:]
        header = self.create_header(func_name)
        closer = self.create_closer(func_name)
        sc_lemmas = " "
        sc_proofs = " "
        nu_file_name = func_name+".pvs"
        with open (nu_file_name,'w') as nu_block:          
            for i, value in enum_list:
                if i >= 7 and i <= 6+up_bound : # body length + the lines above it
                    pvsline = value[0:7] #  important items in each line's format
                    name_i = pvsline[0] 
                    index= name_i[-2:]
                    coln = pvsline[1]
                    theory = pvsline[2]
                    equal = pvsline[3]
                    inst_g_name = pvsline[4]
                    lsq_brac =  pvsline[5]
                    pre_state = pvsline[6]
                    y  = value[7:] # {{ Diag := bv[32] ( 0b1..0 ) as a list 
                    bv = y[5][2:] # 1...0
                    ys = ' '.join(y) # put it back as a string
                    bv_decode = self.pa_decode(bv)
                    max_len = body_len[0]
                    ident   = max(max_len,10)
                    if name_i[0:5] == 'hint_': # replaces hint_i with pac/aut_i
                        nu_name = bv_decode+index
                        sc_lemmas = self.create_lemma(nu_name) # generates the soundmess lemma
                        sc_proofs = self.create_proof(func_name,nu_name, pre_state) # construct the proof script
                        xs = nu_name.ljust(ident," ") + coln + " " + theory + " " + equal + " " + bv_decode.ljust(ident-2,' ') + lsq_brac.ljust(3,' ')+ pre_state.ljust(ident+5,' ') + "]" + " " 
                        nu_inst = xs + ys[2:].rjust(4,' ')
                        nu_block.write(nu_inst+"\n")
                    else: # replaces hint_i.post with pac/aut_i.post
                        if pre_state[0:5] == 'hint_':
                            nu_pre_state = nu_name+".post"
                            xs = name_i.ljust(ident," ") + coln + " " + theory + " " + equal + " " + inst_g_name.ljust(ident-2,' ') + lsq_brac.ljust(3,' ')+ nu_pre_state.ljust(ident+5,' ') + "]" + " "
                        else:  
                            xs = name_i.ljust(ident," ") + coln + " " + theory + " " + equal + " " + inst_g_name.ljust(ident-2,' ') + lsq_brac.ljust(3,' ')+ pre_state.ljust(ident+5,' ') + "]" + " " 
                        nu_inst = xs + ys[2:].rjust(4,' ')
                        nu_block.write(nu_inst+"\n")
                else: 
                    pvsline = " ".join(value)
                    if i == 0:
                        nu_block.write("func_"+pvsline+"\n\n")
                    elif pvsline[0:3] != 'END':
                        nu_block.write(pvsline+"\n")
                    else: 
                        if sc_lemmas != " ":
                            #raise NameError('sc_not_empty')
                            local_properties_and_proofs   = sc_lemmas+"\n\n"+sc_proofs+"\n\n"
                        #else: local_properties_and_proofs = ""   
                            t_func_name = "t_"+func_name+".pvs"
                            with open(t_func_name,'w') as test_file:
                                test_file.write(header+"\n") 
                                test_file.write(local_properties_and_proofs)
                                test_file.write(closer)
                        nu_block.write("END func_"+pvsline[4:]) 
